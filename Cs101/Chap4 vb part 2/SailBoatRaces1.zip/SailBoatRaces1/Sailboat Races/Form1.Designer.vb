﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.lblRank3 = New System.Windows.Forms.Label()
        Me.lblRank2 = New System.Windows.Forms.Label()
        Me.lblRank1 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.lblBoat3Total = New System.Windows.Forms.Label()
        Me.txtBoat3R4 = New System.Windows.Forms.TextBox()
        Me.txtBoat2R4 = New System.Windows.Forms.TextBox()
        Me.txtBoat1R4 = New System.Windows.Forms.TextBox()
        Me.txtBoat3R3 = New System.Windows.Forms.TextBox()
        Me.txtBoat2R3 = New System.Windows.Forms.TextBox()
        Me.txtBoat1R3 = New System.Windows.Forms.TextBox()
        Me.txtBoat3R2 = New System.Windows.Forms.TextBox()
        Me.txtBoat2R2 = New System.Windows.Forms.TextBox()
        Me.txtBoat1R2 = New System.Windows.Forms.TextBox()
        Me.txtBoat3R1 = New System.Windows.Forms.TextBox()
        Me.txtBoat2R1 = New System.Windows.Forms.TextBox()
        Me.txtBoat1R1 = New System.Windows.Forms.TextBox()
        Me.lblBoat2Total = New System.Windows.Forms.Label()
        Me.lblBoat1Total = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.btnCalculateTotal = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip()
        Me.lblStatusError = New System.Windows.Forms.ToolStripStatusLabel()
        Me.GroupBox1.SuspendLayout()
        Me.StatusStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.SystemColors.ControlLight
        Me.GroupBox1.Controls.Add(Me.lblRank3)
        Me.GroupBox1.Controls.Add(Me.lblRank2)
        Me.GroupBox1.Controls.Add(Me.lblRank1)
        Me.GroupBox1.Controls.Add(Me.Label12)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.lblBoat3Total)
        Me.GroupBox1.Controls.Add(Me.txtBoat3R4)
        Me.GroupBox1.Controls.Add(Me.txtBoat2R4)
        Me.GroupBox1.Controls.Add(Me.txtBoat1R4)
        Me.GroupBox1.Controls.Add(Me.txtBoat3R3)
        Me.GroupBox1.Controls.Add(Me.txtBoat2R3)
        Me.GroupBox1.Controls.Add(Me.txtBoat1R3)
        Me.GroupBox1.Controls.Add(Me.txtBoat3R2)
        Me.GroupBox1.Controls.Add(Me.txtBoat2R2)
        Me.GroupBox1.Controls.Add(Me.txtBoat1R2)
        Me.GroupBox1.Controls.Add(Me.txtBoat3R1)
        Me.GroupBox1.Controls.Add(Me.txtBoat2R1)
        Me.GroupBox1.Controls.Add(Me.txtBoat1R1)
        Me.GroupBox1.Controls.Add(Me.lblBoat2Total)
        Me.GroupBox1.Controls.Add(Me.lblBoat1Total)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(40, 32)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(752, 249)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Race Results"
        '
        'lblRank3
        '
        Me.lblRank3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblRank3.Location = New System.Drawing.Point(668, 191)
        Me.lblRank3.Name = "lblRank3"
        Me.lblRank3.Size = New System.Drawing.Size(61, 26)
        Me.lblRank3.TabIndex = 27
        '
        'lblRank2
        '
        Me.lblRank2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblRank2.Location = New System.Drawing.Point(668, 126)
        Me.lblRank2.Name = "lblRank2"
        Me.lblRank2.Size = New System.Drawing.Size(61, 26)
        Me.lblRank2.TabIndex = 25
        '
        'lblRank1
        '
        Me.lblRank1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblRank1.Location = New System.Drawing.Point(668, 65)
        Me.lblRank1.Name = "lblRank1"
        Me.lblRank1.Size = New System.Drawing.Size(61, 26)
        Me.lblRank1.TabIndex = 26
        '
        'Label12
        '
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(668, 15)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(61, 34)
        Me.Label12.TabIndex = 24
        Me.Label12.Text = "Rank"
        Me.Label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(27, 194)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(77, 20)
        Me.Label3.TabIndex = 3
        Me.Label3.Text = "Boat #3:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(27, 68)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(77, 20)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Boat #1:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(27, 129)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(77, 20)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Boat #2:"
        '
        'lblBoat3Total
        '
        Me.lblBoat3Total.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblBoat3Total.Location = New System.Drawing.Point(571, 191)
        Me.lblBoat3Total.Name = "lblBoat3Total"
        Me.lblBoat3Total.Size = New System.Drawing.Size(61, 26)
        Me.lblBoat3Total.TabIndex = 23
        '
        'txtBoat3R4
        '
        Me.txtBoat3R4.Location = New System.Drawing.Point(453, 191)
        Me.txtBoat3R4.Name = "txtBoat3R4"
        Me.txtBoat3R4.Size = New System.Drawing.Size(61, 26)
        Me.txtBoat3R4.TabIndex = 20
        '
        'txtBoat2R4
        '
        Me.txtBoat2R4.Location = New System.Drawing.Point(453, 126)
        Me.txtBoat2R4.Name = "txtBoat2R4"
        Me.txtBoat2R4.Size = New System.Drawing.Size(61, 26)
        Me.txtBoat2R4.TabIndex = 19
        '
        'txtBoat1R4
        '
        Me.txtBoat1R4.Location = New System.Drawing.Point(453, 65)
        Me.txtBoat1R4.Name = "txtBoat1R4"
        Me.txtBoat1R4.Size = New System.Drawing.Size(61, 26)
        Me.txtBoat1R4.TabIndex = 18
        '
        'txtBoat3R3
        '
        Me.txtBoat3R3.Location = New System.Drawing.Point(345, 191)
        Me.txtBoat3R3.Name = "txtBoat3R3"
        Me.txtBoat3R3.Size = New System.Drawing.Size(61, 26)
        Me.txtBoat3R3.TabIndex = 17
        '
        'txtBoat2R3
        '
        Me.txtBoat2R3.Location = New System.Drawing.Point(345, 126)
        Me.txtBoat2R3.Name = "txtBoat2R3"
        Me.txtBoat2R3.Size = New System.Drawing.Size(61, 26)
        Me.txtBoat2R3.TabIndex = 16
        '
        'txtBoat1R3
        '
        Me.txtBoat1R3.Location = New System.Drawing.Point(345, 65)
        Me.txtBoat1R3.Name = "txtBoat1R3"
        Me.txtBoat1R3.Size = New System.Drawing.Size(61, 26)
        Me.txtBoat1R3.TabIndex = 15
        '
        'txtBoat3R2
        '
        Me.txtBoat3R2.Location = New System.Drawing.Point(238, 191)
        Me.txtBoat3R2.Name = "txtBoat3R2"
        Me.txtBoat3R2.Size = New System.Drawing.Size(61, 26)
        Me.txtBoat3R2.TabIndex = 14
        '
        'txtBoat2R2
        '
        Me.txtBoat2R2.Location = New System.Drawing.Point(238, 126)
        Me.txtBoat2R2.Name = "txtBoat2R2"
        Me.txtBoat2R2.Size = New System.Drawing.Size(61, 26)
        Me.txtBoat2R2.TabIndex = 13
        '
        'txtBoat1R2
        '
        Me.txtBoat1R2.Location = New System.Drawing.Point(238, 65)
        Me.txtBoat1R2.Name = "txtBoat1R2"
        Me.txtBoat1R2.Size = New System.Drawing.Size(61, 26)
        Me.txtBoat1R2.TabIndex = 12
        '
        'txtBoat3R1
        '
        Me.txtBoat3R1.Location = New System.Drawing.Point(128, 191)
        Me.txtBoat3R1.Name = "txtBoat3R1"
        Me.txtBoat3R1.Size = New System.Drawing.Size(61, 26)
        Me.txtBoat3R1.TabIndex = 11
        '
        'txtBoat2R1
        '
        Me.txtBoat2R1.Location = New System.Drawing.Point(128, 126)
        Me.txtBoat2R1.Name = "txtBoat2R1"
        Me.txtBoat2R1.Size = New System.Drawing.Size(61, 26)
        Me.txtBoat2R1.TabIndex = 10
        '
        'txtBoat1R1
        '
        Me.txtBoat1R1.Location = New System.Drawing.Point(128, 65)
        Me.txtBoat1R1.Name = "txtBoat1R1"
        Me.txtBoat1R1.Size = New System.Drawing.Size(61, 26)
        Me.txtBoat1R1.TabIndex = 9
        '
        'lblBoat2Total
        '
        Me.lblBoat2Total.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblBoat2Total.Location = New System.Drawing.Point(571, 126)
        Me.lblBoat2Total.Name = "lblBoat2Total"
        Me.lblBoat2Total.Size = New System.Drawing.Size(61, 26)
        Me.lblBoat2Total.TabIndex = 10
        '
        'lblBoat1Total
        '
        Me.lblBoat1Total.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblBoat1Total.Location = New System.Drawing.Point(571, 65)
        Me.lblBoat1Total.Name = "lblBoat1Total"
        Me.lblBoat1Total.Size = New System.Drawing.Size(61, 26)
        Me.lblBoat1Total.TabIndex = 21
        '
        'Label8
        '
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(571, 15)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(61, 34)
        Me.Label8.TabIndex = 8
        Me.Label8.Text = "Total"
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(450, 22)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(66, 20)
        Me.Label7.TabIndex = 7
        Me.Label7.Text = "Race 4"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(342, 22)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(66, 20)
        Me.Label6.TabIndex = 6
        Me.Label6.Text = "Race 3"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(235, 22)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(66, 20)
        Me.Label5.TabIndex = 5
        Me.Label5.Text = "Race 2"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(125, 22)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(66, 20)
        Me.Label4.TabIndex = 4
        Me.Label4.Text = "Race 1"
        '
        'btnCalculateTotal
        '
        Me.btnCalculateTotal.Location = New System.Drawing.Point(67, 316)
        Me.btnCalculateTotal.Name = "btnCalculateTotal"
        Me.btnCalculateTotal.Size = New System.Drawing.Size(160, 44)
        Me.btnCalculateTotal.TabIndex = 1
        Me.btnCalculateTotal.Text = "Calculate Totals"
        Me.btnCalculateTotal.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(319, 316)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(114, 44)
        Me.btnClear.TabIndex = 2
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnClose
        '
        Me.btnClose.Location = New System.Drawing.Point(532, 316)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(114, 44)
        Me.btnClose.TabIndex = 3
        Me.btnClose.Text = "Close"
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'StatusStrip1
        '
        Me.StatusStrip1.ImageScalingSize = New System.Drawing.Size(24, 24)
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.lblStatusError})
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 378)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(816, 22)
        Me.StatusStrip1.TabIndex = 3
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'lblStatusError
        '
        Me.lblStatusError.Name = "lblStatusError"
        Me.lblStatusError.Size = New System.Drawing.Size(0, 15)
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(816, 400)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnCalculateTotal)
        Me.Controls.Add(Me.GroupBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Form1"
        Me.Text = "Race Results"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents btnCalculateTotal As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents btnClose As Button
    Friend WithEvents lblBoat3Total As Label
    Friend WithEvents txtBoat3R4 As TextBox
    Friend WithEvents txtBoat2R4 As TextBox
    Friend WithEvents txtBoat1R4 As TextBox
    Friend WithEvents txtBoat3R3 As TextBox
    Friend WithEvents txtBoat2R3 As TextBox
    Friend WithEvents txtBoat1R3 As TextBox
    Friend WithEvents txtBoat3R2 As TextBox
    Friend WithEvents txtBoat2R2 As TextBox
    Friend WithEvents txtBoat1R2 As TextBox
    Friend WithEvents txtBoat3R1 As TextBox
    Friend WithEvents txtBoat2R1 As TextBox
    Friend WithEvents txtBoat1R1 As TextBox
    Friend WithEvents lblBoat2Total As Label
    Friend WithEvents lblBoat1Total As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents StatusStrip1 As StatusStrip
    Friend WithEvents lblStatusError As ToolStripStatusLabel
    Friend WithEvents lblRank3 As Label
    Friend WithEvents lblRank2 As Label
    Friend WithEvents lblRank1 As Label
    Friend WithEvents Label12 As Label
End Class
