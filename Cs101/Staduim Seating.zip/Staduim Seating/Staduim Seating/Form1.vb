﻿'************************************************************************************************
'Name: Jose Martinez Perez
'Date:11/7/2020
'Puporse:
'Input:
'processing:
'Output:
'***************************************************************************************************
Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click 'Step 0 - Declare Variable
        ' Step 0 - Declare variebles
        ' Local-Level constants for the ticket Prices
        Dim decCLASS_A_PRICE As Decimal = 15D
        Dim deCLASS_B_PRICE As Decimal = 12D
        Dim decCLASS_C_PRICE As Decimal = 9D

        'Local Level variable to hold Tickets Sold.
        Dim decClassATickets As Decimal = 0.0D
        Dim decClassBTickets As Decimal = 0.0D
        Dim decClassCTickets As Decimal = 0.0D
        Dim decClassARevenue As Decimal = 0.0D
        Dim decClassBRevenue As Decimal = 0.0D
        Dim decClassCRevenue As Decimal = 0.0D

        'Total Revenue
        Dim decTotalRevenue As Decimal = 0.0D

        'Step 1 - Input
        'Syntax:
        '       intVairbale = CInt(txtControl.Text)
        '       dblVAriable = CDbl(txtControl.Text)
        '       decVariable = CDec(txtControl.Text)
        Try
            'Get the Tickets sold and convert them to decimals.
            decClassATickets = CDec(txtClassA.Text)
            decClassBTickets = CDec(txtClassB.Text)
            decClassCTickets = CDec(txtClassC.Text)

            'Step 2 - Processing
            'Syntax:
            '       variable = expression
            'Calculate(Multiply) the Amount of tickets sold by the Each Class Price.
            decClassARevenue = decClassATickets * decCLASS_A_PRICE
            decClassBRevenue = decClassBTickets * deCLASS_B_PRICE
            decClassCRevenue = decClassCTickets * decCLASS_C_PRICE

            'Add all revenues of all three classes A+B+C
            decTotalRevenue = decClassARevenue + decClassBRevenue + decClassCRevenue

            'Step 3 - Output
            'Syntax:
            '       lblControl.Text = numericVariable.ToString()
            'Display the total in each class in the corresponding label.
            lblClassA.Text = decClassARevenue.ToString("C")
            lblClassB.Text = decClassBRevenue.ToString("C")
            lblClassC.Text = decClassCRevenue.ToString("C")

            ' Total Revenue in lblTotatRevenue
            lblTotalRevenue.Text = decTotalRevenue.ToString("C")
        Catch
            'Display an Error Message.
            MessageBox.Show("Error: Be sure to enter Valid Numeric Values")
        End Try
    End Sub

    Private Sub txtClassB_TextChanged(sender As Object, e As EventArgs) Handles txtClassB.TextChanged

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        ' Clear the labels from
        txtClassA.Clear()
        txtClassB.Clear()
        txtClassC.Clear()

        lblClassA.Text = ""
        lblClassB.Text = ""
        lblClassC.Text = ""
        lblTotalRevenue.Text = String.Empty

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Me.Close()

    End Sub
End Class
